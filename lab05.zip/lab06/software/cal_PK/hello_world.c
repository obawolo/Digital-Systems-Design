
#include <stdio.h>
#include <unistd.h>
#include "system.h"
#include "altera_avalon_pio_regs.h"
int main()
{
	IOWR_ALTERA_AVALON_PIO_DATA(LED_0_BASE, 64);
	IOWR_ALTERA_AVALON_PIO_DATA(LED_10_BASE, 64);
	int in0, in1, inalu; //inputs
	int out0, out10; //outputs
	int result, result0, result10; //calculation result
	printf("Hello from Nios II!\n");
	//retriving input0, input1, inputop
	in0 = IORD_ALTERA_AVALON_PIO_DATA(INPUT_0_BASE);
	in1 = IORD_ALTERA_AVALON_PIO_DATA(INPUT_1_BASE);
	inalu = IORD_ALTERA_AVALON_PIO_DATA(INPUT_OP_BASE);

	//calculation
	switch (inalu)
	   {
	   	   case 0: //add
	   		   result = in0 + in1;
	   		   break;
	   	   case 1: //subtract
	   		   result = in0 - in1;
	   		   break;
	   	   case 2: //multiply
	   		   result = in0 * in1;
	   		   break;
	   	   case 3: //divide
	   		   result = in0 / in1;
	   		   break;
	   	   default:
	   		   break;
	   }

	result0 = result % 10; //result one decimal integer
	result10 = result / 10; //result ten decimal integer

	//decoding one decimal digit of the calculation into seven segment integer
	switch (result0)
          	   {
          	   	   case 0:
          	   		   out0 = 64;
          	   		   break;
          	   	   case 1:
          	   		   out0 = 121;
          	   		   break;
          	   	   case 2:
          	   		   out0 = 36;
          	   		   break;
          	   	   case 3:
          	   		   out0 = 48;
          	   		   break;
          	   	   case 4:
          	   		   out0 = 25;
          	   		   break;
          	   	   case 5:
          	   		   out0 = 18;
          	   		   break;
          	   	   case 6:
          	   		   out0 = 2;
          	   		   break;
          	   	   case 7:
          	   		   out0 = 120;
          	   		   break;
          	   	   case 8:
          	   		   out0 = 0;
          	   		   break;
          	   	// anything greater than and equal to 9 is 9 seven segment decoded integer
          	   	   default:
          	   		   out0 = 16;
          	   }

	switch (result10)
          	   {
          	   	   case 0:
          	   		   out10 = 64;
          	   		   break;
          	   	   case 1:
          	   		   out10 = 121;
          	   		   break;
          	   	   case 2:
          	   		   out10 = 36;
          	   		   break;
          	   	   case 3:
          	   		   out10 = 48;
          	   		   break;
          	   	   case 4:
          	   		   out10 = 25;
          	   		   break;
          	   	   case 5:
          	   		   out10 = 18;
          	   		   break;
          	   	   case 6:
          	   		   out10 = 2;
          	   		   break;
          	   	   case 7:
          	   		   out10 = 120;
          	   		   break;
          	   	   case 8:
          	   		   out10 = 0;
          	   		   break;
          	   	// anything greater than and equal to 9 is 9 seven segment decoded integer
          	   	   default:
          	   		   out10 = 16;
          	   }

		IOWR_ALTERA_AVALON_PIO_DATA(LED_0_BASE, out0);
		IOWR_ALTERA_AVALON_PIO_DATA(LED_10_BASE, out10);

		return 0;
}
